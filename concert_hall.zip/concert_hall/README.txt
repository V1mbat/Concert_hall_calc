Use:
Estimations.m for reverb time, strength and clarity
totalreduction.m for doublewall